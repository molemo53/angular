import { browser, element, by, ElementFinder } from 'protractor';
import { promise } from 'selenium-webdriver';
import { BrowserDynamicTestingModule, platformBrowserDynamicTesting } from '@angular/platform-browser-dynamic/testing';
import { Component, NgModule } from '@angular/core';
import {TestBed, fakeAsync, tick} from '@angular/core/testing';
import {Routes} from "@angular/router";
import { RouterTestingModule } from '@angular/router/testing';
import {Location} from "@angular/common";

export class ManageUser{

    getParentmenu(){
        return element(by.id('Menu-menu-parent-id')).getWebElement();

    }

    getFileMenu(){
        return element(by.id('File-menu-parent-id')).getWebElement();

    }

   

    getAdminBtn(){
        return element(by.id('Administration-menu-parent-id')).getWebElement();

    }
    
    getAdminUserBtn(){
        return element(by.id('Users-menu-child-id')).getWebElement();
 
    }

    getAddNewUserBtn(){
        return element(by.id('user-management-user-activity-add-button')).getWebElement();

    }

    getUserSettingBtn(){
    return element(by.id('User Settings-menu-child-id')).getWebElement();
    }

    

    getAddUserBtn(){
        return element(by.id('Users-menu-route-id')).getWebElement();

    }

 




}