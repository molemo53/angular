
import { browser, element, by, ElementFinder } from 'protractor';
import { promise } from 'selenium-webdriver';
import { BrowserDynamicTestingModule, platformBrowserDynamicTesting } from '@angular/platform-browser-dynamic/testing';
import { Component, NgModule } from '@angular/core';
import {TestBed, fakeAsync, tick} from '@angular/core/testing';
import {Routes} from "@angular/router";
import { RouterTestingModule } from '@angular/router/testing';
import {Location} from "@angular/common";


export class LoginPage {
  
    navigateTo(){
        return browser.get('/Login');
    }


   getTextLogin(){
        return element(by.css('app-login h1')).getText();

      }


    getEmailTextbox()  {
        return  element(by.id('tb_username-input')).getWebElement();
        
       }

      

    getPasswordTextbox() {
        return element(by.id('tb_password-input')).getWebElement();

       }
    

       getSubmitButton() {
        return element(by.id('login-button')).getWebElement();

       }
       

      

}

