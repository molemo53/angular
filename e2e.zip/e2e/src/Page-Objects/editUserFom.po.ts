import { browser, element, by, ElementFinder } from 'protractor';
import { promise } from 'selenium-webdriver';
import { BrowserDynamicTestingModule, platformBrowserDynamicTesting } from '@angular/platform-browser-dynamic/testing';
import { Component, NgModule } from '@angular/core';
import {TestBed, fakeAsync, tick} from '@angular/core/testing';
import {Routes} from "@angular/router";
import { RouterTestingModule } from '@angular/router/testing';
import {Location} from "@angular/common";

export class EditUserForm{

    selectUser(){
        return element(by.xpath("//div[contains(text(),'test4@tsti.co.za')]")).getWebElement();
    }

    getEditBtn(){
        return element(by.id('user-management-user-activity-edit-button')).getWebElement();
    }

    getUserAtivityForm(){
        return element(by.id('mat-tab-label-1-2')).getWebElement();
    }

    getGeneralForm(){
        return element(by.id('mat-tab-label-1-0')).getWebElement();
    }



}