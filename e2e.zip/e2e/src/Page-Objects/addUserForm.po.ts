import { browser, element, by, ElementFinder } from 'protractor';
import { promise } from 'selenium-webdriver';
import { BrowserDynamicTestingModule, platformBrowserDynamicTesting } from '@angular/platform-browser-dynamic/testing';
import { Component, NgModule } from '@angular/core';
import {TestBed, fakeAsync, tick} from '@angular/core/testing';
import {Routes} from "@angular/router";
import { RouterTestingModule } from '@angular/router/testing';
import {Location} from "@angular/common";

export class UserForm{

//General Fom Add user
getGeneralFrom(){
        return element(by.id('mat-tab-label-1-0')).getWebElement();
    
}

getTb_email(){
    return element(by.id('tb_UserName')).getWebElement();

}

getTb_name(){
    return element(by.id('tb_Name')).getWebElement();
}


getTb_activeDirectory(){
    return element(by.id('tb_ActiveDirectoryUser')).getWebElement();
}

getTb_id(){
    return element(by.id('tb_IdentificationNumber')).getWebElement();
}

getTb_contactsNo(){
    return element(by.id('tb_ContactNumber')).getWebElement();

}

getTb_mobileNo(){
    return element(by.id('tb_MobileNumber')).getWebElement();
}

getUserLevel(){
    return element(by.id('cb_entities-select')).getWebElement();
}

getRoles(){
    return element(by.id('cb_roles-select')).getWebElement();
}

getSelectRoles(){
    return element(by.xpath("//div[@class='cdk-overlay-container']//lib-get-combo[1]//div[1]//div[3]//div[1]"));
    
}

selectRoles(){
   return element(by.xpath("//tr[@id='stt-multi-select-option-entities-select_4']//td[1]")); 

}

getCheckboxAdminstration(){
    return element(by.xpath("//mat-slide-toggle[@id='administrator-checkbox-id']//div[@class='mat-slide-toggle-bar']"));
    
}

getCheckboxCompliance(){
    return element(by.xpath("//mat-slide-toggle[@id='compliance-officer-checkbox-id']//div[@class='mat-slide-toggle-bar']"));
}

getDefaultQuantity(){
    return element(by.id('tbNum_defaultQuantityInput')).getWebElement();
}

getGoodTillDays(){
    return element(by.id('tbNum_DefaultGoodTillDateDays')).getWebElement();
}

getMaxQuantity(){
    return element(by.id('tbNum_maximumTradingQuantityInput')).getWebElement();

}

getMaxPrice(){
    return element(by.id('tbNum_maximumPricePremiumChangeInput')).getWebElement();
}

getMaxRate(){
    return element(by.id('tbNum_maximumRateChangeInput')).getWebElement();

}

getMaxVol(){
    return element(by.id('tbNum_maximumVolatilityChangeInput')).getWebElement();
}

getCheckBoxTradeNotification(){
    return element(by.xpath("//mat-slide-toggle[@id='trade-notification-checkbox-id']//div[@class='mat-slide-toggle-thumb']")).getWebElement();
 
}

getCheckBoxFollowBid(){
    return element(by.xpath("//mat-slide-toggle[@id='follow-best-bid-checkbox-id']//div[@class='mat-slide-toggle-thumb']"));
   
}

getCheckBoxCumulativeDepth(){
    return element(by.xpath("//mat-slide-toggle[@id='cumulative-depth-checkbox-id']//div[@class='mat-slide-toggle-thumb']"));
    

}

getDefaultReferance(){
    return element(by.id('tb_default-reference-number')).getWebElement();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//Markets

getMarketsForm(){
    return element(by.id('mat-tab-label-2-1')).getWebElement();
}

getSettingAddMarketBtn(){
    return element(by.id('settings-markets-add-button')).getWebElement();
}

getMarketSetupSelection(){
    return element(by.id('cb_market-selection')).getWebElement();
}

getBrokerCode(){
    return element(by.id('cb_broker-selection')).getWebElement();
}
getTraderCode(){
    return element(by.id('cb_trader-selection')).getWebElement();
}

getBrokerType(){
    return element(by.id('cb_user-types-selection')).getWebElement();
}

getCheckBoxAllTraders(){
    return  element(by.xpath("//mat-slide-toggle[@id='all-traders-data-checkbox-id']//div[@class='mat-slide-toggle-thumb']"));
   
}

getCheckBoxBrokerTrade(){
    return element(by.xpath("//mat-slide-toggle[@id='broker-trader-checkbox-id']//div[@class='mat-slide-toggle-thumb']"));
}

getAddMarketBtn(){
    return element(by.id('settings-markets-modal-done-button')).getWebElement();
    
}

//button[@id='settings-markets-modal-done-button']//div[@class='mat-ripple mat-button-ripple']

getSelectMarket(){
//return element(by.xpath("//tr[@class='mat-row cdk-row ng-star-inserted selected']")).getWebElement();
return element(by.xpath("//div[contains(text(),'ZARX')]")).getWebElement();

}

getSelectPrinciples(){
return element(by.xpath("//div[contains(text(),'ONE237')]")).getWebElement();
}

getPrincinplesBtn(){

    return element(by.id('settings-markets-associations-add-button')).getWebElement();

}


getSubmitAddUserBtn(){
    return element(by.id('settings-done-button')).getWebElement();
}



}