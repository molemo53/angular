import { browser, element, by, ElementFinder } from 'protractor';
import { promise } from 'selenium-webdriver';
import { BrowserDynamicTestingModule, platformBrowserDynamicTesting } from '@angular/platform-browser-dynamic/testing';
import { Component, NgModule } from '@angular/core';
import {TestBed, fakeAsync, tick} from '@angular/core/testing';
import {Routes} from "@angular/router";
import { RouterTestingModule } from '@angular/router/testing';
import {Location} from "@angular/common";

export class AddWatchList{

    selectUserSettings(){
        return element(by.xpath("//a[@id='User Settings-menu-child-id']")).getWebElement();
    }

    selectWatchList(){
        return element(by.xpath("//div[@id='mat-tab-label-0-2']")).getWebElement();
    }

    getAddBtnWatchList(){
        return element(by.xpath("//button[@id='settings-watch-lists-add-button']")).getWebElement();
    }
//////////////////////////////////////////////////////////////////
    getNameWatchlist(){
        return element(by.xpath("//input[@id='tb_watchlist-name']")).getWebElement();
    }

    getDescription(){
        return element(by.xpath("//input[@id='tb_watchlist-description']")).getWebElement();
    }
/*
    getDropDownMarket(){
        return element(by.xpath("//body/div[5]/div[2]/div[1]/mat-dialog-container[1]/app-watch-list-modal[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/lib-get-combo[1]/div[1]/div[3]/div[1]/fa-icon[1]/*[1]")).getWebElement();
        //body/div[5]/div[2]/div[1]/mat-dialog-container[1]/app-watch-list-modal[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/lib-get-combo[1]/div[1]/div[3]/div[1]
    }

    SelectZarx(){
        return element(by.xpath("//tbody/tr[@id='stt-multi-select-option-watchlist-market-selection_0']/td[1]")).getWebElement();
    }
    
    getDropDownSecurity(){
        return element(by.xpath("//body/div[5]/div[2]/div[1]/mat-dialog-container[1]/app-watch-list-modal[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/lib-get-combo[1]/div[1]/div[3]/div[1]")).getWebElement();
        //body/div[5]/div[2]/div[1]/mat-dialog-container[1]/app-watch-list-modal[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/lib-get-combo[1]/div[1]/div[3]/div[1]
        
    }
    
    selectSecurity(){
        return element(by.xpath("//tbody/tr[@id='stt-multi-select-option-watchlist-security-selection_2']/td[1]")).getWebElement();
    }
*/
    checkAvailableContract(){
        return element(by.xpath("//body[1]/div[5]/div[2]/div[1]/mat-dialog-container[1]/app-watch-list-modal[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/lib-datatable[1]/div[2]/table[1]/thead[1]/tr[1]/th[1]/mat-checkbox[1]/label[1]/div[1]")).getWebElement();
    }

    getAddBtnContract(){
        return element(by.xpath("//button[@id='security-add-button']")).getWebElement();
    }

    getSubmitBtn(){
        return element(by.xpath("//button[@id='settings-watch-lists-modal-submit-button']")).getWebElement();
    }
}

//body/div[5]/div[2]/div[1]/mat-dialog-container[1]/app-watch-list-modal[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]