import { AppPage } from '../Page-Objects/app.po';
import { browser, by, element } from 'protractor';

const expectedH1 = "Avvento";
const expectedTitle = `${expectedH1}`;

describe('Avvento App Page', () => {

    let page: AppPage;
    

    browser.waitForAngularEnabled(false);
    beforeEach(() => {
        page = new AppPage();
            
    });


    it(`has title '${expectedTitle}'`, () => {
        page.navigateTo();   
        expect(browser.getTitle()).toEqual(expectedTitle);
        
    });


});