'use strict'; // necessary for es6 output in node

import { LoginPage } from '../Page-Objects/login.po';
import {ManageUser} from '../Page-Objects/manageUser.po';
import {UserForm} from'../Page-Objects/addUserForm.po'
import {EditUserForm} from '../Page-Objects/editUserFom.po';
import {AddWatchList}from '../Page-Objects/addWatchList.po';
import { browser, element, by, ElementFinder } from 'protractor';
import { promise } from 'selenium-webdriver';
import {Location, getLocaleExtraDayPeriodRules} from "@angular/common";
import {TestBed, fakeAsync, tick} from '@angular/core/testing';
import {RouterTestingModule} from "@angular/router/testing";
import {Router} from "@angular/router";
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
describe('Avvento start Application', () => {


    let page: LoginPage;

    browser.ignoreSynchronization = true; // for non-angular websites
    browser.manage().window().maximize();
    browser.manage().timeouts().implicitlyWait(40000);
    

    beforeEach(() => {
        page = new LoginPage();
        page.navigateTo();
        browser.sleep(10000);
    });


    it('User loggin in', () => {   
        page.getEmailTextbox().sendKeys('mtseleng@tsti.co.za');
        page.getPasswordTextbox().sendKeys('Password2*');
        page.getSubmitButton().click();
        console.log('Logged in');
        browser.sleep(10000);

       });


});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
describe('Main manu', ()=>{

    let page: ManageUser;
    let page2: UserForm;
    let page3: EditUserForm;
    let addwatchlist: AddWatchList;
    var originalTimeout;
    beforeEach(() => {

        originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;

        page = new ManageUser();
        page2 = new UserForm();
        page3 = new EditUserForm();
        addwatchlist = new AddWatchList();
    });

    it('Route to AddUser', () => {  
        page.getParentmenu().click();
      

       page.getFileMenu().click();
       addwatchlist.selectUserSettings().click();
       addwatchlist.selectWatchList().click();
       addwatchlist.getAddBtnWatchList().click();
       addwatchlist.getNameWatchlist().sendKeys("Thrid Test");
       addwatchlist.getDescription().sendKeys("Testing");
      // addwatchlist.getDropDownMarket().click();
     //  addwatchlist.SelectZarx().click();
     //  addwatchlist.getDropDownSecurity().click();
     //  addwatchlist.selectSecurity().click();
       browser.sleep(1000);
       addwatchlist.checkAvailableContract().click();
       addwatchlist.getAddBtnContract().click();
       addwatchlist.getSubmitBtn().click();
       browser.sleep(1000);

      // page.getAdminBtn().click();

     ///  page.getAdminUserBtn().click();
     ///  page.getAddUserBtn().click();
     
      
    
    });
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//General
/*    it('Open add user form',()=>{
        page.getAddNewUserBtn().click();
        browser.sleep(1000);
    });

    it('Register user information',()=>{
        page2.getTb_email().sendKeys('test9@tsti.co.za');
        page2.getTb_name().sendKeys('Update Testing ');
        page2.getTb_activeDirectory().sendKeys('99');
        page2.getTb_id().sendKeys('99')
        page2.getTb_contactsNo().sendKeys('99');
        page2.getTb_mobileNo().sendKeys('99');

        
        //element(by.xpath("//lib-get-combo[1]//div[1]//div[3]//div[1]")).click();
      // element(by.xpath( "//lib-get-combo[1]//div[1]//div[3]//div[1]")).click();
      // element(by.xpath("//tr[@id='stt-multi-select-option-entities-select_4']//td[1]")).click();
       
     // page2.getUserLevel().clear();
      //  page2.getSelectRoles().click();
    //    page2.selectRoles().click();

        page2.getCheckboxAdminstration().click();
        page2.getCheckboxCompliance().click();
       

        
//Defaults
        browser.sleep(1000);
        page2.getDefaultQuantity().sendKeys('33');
        page2.getGoodTillDays().sendKeys('33');

browser.sleep(1000);
//Maximun and change Limit
        page2.getMaxQuantity().sendKeys('33');
        page2.getMaxPrice().sendKeys('33');
        page2.getMaxRate().sendKeys('33');
        page2.getMaxVol().sendKeys('33');
//Trading Preferences
        page2.getCheckBoxTradeNotification().click();
        page2.getCheckBoxFollowBid().click();
        page2.getCheckBoxCumulativeDepth().click();

/////////////////////////////////////////////////////////////////////////////////////////////////
//General
        page2.getMarketsForm().click();
        page2.getSettingAddMarketBtn().click();

//Market Setup
        browser.sleep(10000);
        page2.getCheckBoxAllTraders().click();
        page2.getCheckBoxBrokerTrade().click();

        page2.getAddMarketBtn().click();

        ///Adding Principles.
        page2.getSelectMarket().click();

         //Add user
        page2.getSubmitAddUserBtn().click();
        browser.sleep(1000);
        console.log('Users Added');
    });

    describe('It edits a user created', ()=>{

        it('Update user name',()=>{
            page3.selectUser().click();
            page3.getEditBtn().click();
            browser.sleep(1000);
            page2.getTb_name().clear();
            page2.getTb_name().sendKeys('Protractor Angular');
            page2.getSubmitAddUserBtn().click();

            browser.sleep(1000);
            console.log('Editing a user passed');
        });


    });
    */


});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  




